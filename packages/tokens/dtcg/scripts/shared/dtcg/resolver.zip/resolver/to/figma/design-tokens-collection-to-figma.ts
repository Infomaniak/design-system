import Color, { type Coords } from 'colorjs.io';
import { designTokenReferenceToCurlyReference } from '../../../design-token/reference/to/curly-reference/design-token-reference-to-curly-reference.ts';
import { isJsonReference } from '../../../design-token/reference/types/json/is-json-reference.ts';
import type { ValueOrJsonReference } from '../../../design-token/reference/types/json/value-or/value-or-json-reference.ts';
import type { ColorDesignTokenValue } from '../../../design-token/token/types/base/types/color/value/color-design-token-value.ts';
import type { ColorDesignTokenValueComponents } from '../../../design-token/token/types/base/types/color/value/members/components/color-design-token-value-components.ts';
import type { ColorDesignTokenValueComponent } from '../../../design-token/token/types/base/types/color/value/members/components/component/color-design-token-value-component.ts';
import {
  type ArrayDesignTokenName,
  DesignTokensCollection,
  type DesignTokensCollectionToken,
} from '../../design-tokens-collection.ts';

export function designTokensCollectionToFigma(collection: DesignTokensCollection): unknown {
  let output: object = {};

  const addToken = (path: ArrayDesignTokenName, figmaToken: unknown): void => {
    if (path.length === 0) {
      throw new Error('Cannot add token to root');
    }

    let node: any = output;
    const last: number = path.length - 1;

    for (let i: number = 0; i < last; i++) {
      const segment: string = path[i];

      if (!Reflect.has(node, segment)) {
        Reflect.set(node, segment, {});
      }

      node = Reflect.get(node, segment);
    }

    Reflect.set(node, path[last], figmaToken);
  };

  for (const token of collection.tokens({ merge: true })) {
    switch (token.type) {
      case 'color': {
        addToken(token.name, colorDesignTokenToFigmaObject(token));
      }
    }
  }

  return output;
}

export function colorDesignTokenToFigmaObject(token: DesignTokensCollectionToken): unknown {
  return {
    $type: 'color',
    $value: DesignTokensCollection.isCurlyReference(token.value)
      ? designTokenReferenceToCurlyReference(token.value)
      : colorDesignTokenValueToFigmaValue(token.value as ColorDesignTokenValue),
    $description: token.description,
  };
}

function colorDesignTokenValueToFigmaValue({
  colorSpace,
  components,
  alpha,
}: ColorDesignTokenValue): string {
  return new Color({
    space: colorSpace as any,
    coords: (components as ColorDesignTokenValueComponents).map(
      (component: ValueOrJsonReference<ColorDesignTokenValueComponent>): number | null => {
        if (isJsonReference(component)) {
          throw new Error('JSON references are not supported yet.');
        }
        return component === 'none' ? null : (component as number);
      },
    ) as Coords,
    alpha: alpha as number | undefined,
  }).toString({
    format: 'hex',
    collapse: false,
  });
}
