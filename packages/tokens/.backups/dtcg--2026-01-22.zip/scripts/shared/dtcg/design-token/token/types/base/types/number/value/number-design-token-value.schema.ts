import * as z from 'zod';

export const numberDesignTokenValueSchema = z.number();
