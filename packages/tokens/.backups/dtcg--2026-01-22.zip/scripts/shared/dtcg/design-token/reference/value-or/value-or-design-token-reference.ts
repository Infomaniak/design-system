import type { DesignTokenReference } from '../design-token-reference.ts';

export type ValueOrDesignTokenReference<GValue> = GValue | DesignTokenReference;
