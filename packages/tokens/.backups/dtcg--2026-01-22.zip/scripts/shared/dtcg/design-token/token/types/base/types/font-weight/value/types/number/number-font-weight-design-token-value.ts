export type NumberFontWeightDesignTokenValue = number /* [0, 1000] */;
