export type NumberDesignTokenValue = number;
