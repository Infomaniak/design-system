export type SegmentsReference = readonly string[];
