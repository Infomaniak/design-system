/**
 * @inheritDoc https://www.designtokens.org/tr/2025.10/format/#curly-brace-syntax-token-references
 */
export type CurlyReference = `{${string}}`;
