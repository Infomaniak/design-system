import * as z from 'zod';

export const stringFontFamilyDesignTokenValueSchema = z.string();
