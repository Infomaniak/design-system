import * as z from 'zod';

export const dimensionDesignTokenValueValueSchema = z.number();
