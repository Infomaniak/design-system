export type DurationDesignTokenValueValue = number | undefined;
