import * as z from 'zod';

export const durationDesignTokenValueValueSchema = z.number();
