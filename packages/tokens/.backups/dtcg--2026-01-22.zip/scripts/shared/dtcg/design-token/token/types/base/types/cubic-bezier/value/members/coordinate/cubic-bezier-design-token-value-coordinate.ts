export type CubicBezierDesignTokenValueCoordinate = number;
