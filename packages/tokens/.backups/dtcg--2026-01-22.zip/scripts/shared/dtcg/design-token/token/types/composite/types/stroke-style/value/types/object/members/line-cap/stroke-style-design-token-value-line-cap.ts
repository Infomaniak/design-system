export type StrokeStyleDesignTokenValueLineCap = 'round' | 'butt' | 'square';
