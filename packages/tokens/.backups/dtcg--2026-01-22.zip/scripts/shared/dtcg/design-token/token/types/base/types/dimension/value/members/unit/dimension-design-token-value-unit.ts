export type DimensionDesignTokenValueUnit = 'px' | 'rem';
