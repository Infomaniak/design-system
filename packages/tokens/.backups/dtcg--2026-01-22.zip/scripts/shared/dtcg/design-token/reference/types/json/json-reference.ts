export interface JsonReference {
  readonly $ref: string;
}
