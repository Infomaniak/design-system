export type ColorDesignTokenValueComponent = number | 'none';
