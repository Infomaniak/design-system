import type { CurlyReference } from '../curly-reference.ts';

export type ValueOrCurlyReference<GValue> = GValue | CurlyReference;
