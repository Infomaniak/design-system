import type { ValueOrJsonReference } from '../../../../../../../../reference/types/json/value-or/value-or-json-reference.js';

export type StringArrayFontFamilyDesignTokenValue = readonly ValueOrJsonReference<string>[];
