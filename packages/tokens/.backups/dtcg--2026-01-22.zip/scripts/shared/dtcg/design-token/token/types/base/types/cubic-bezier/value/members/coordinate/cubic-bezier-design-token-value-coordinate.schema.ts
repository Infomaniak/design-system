import * as z from 'zod';

export const cubicBezierDesignTokenValueCoordinateSchema = z.number();
