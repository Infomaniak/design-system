import type { DesignToken } from './design-token.js';

export type GenericDesignToken = DesignToken<any, any>;
