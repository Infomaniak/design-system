export type DurationDesignTokenValueUnit = 'ms' | 's';
