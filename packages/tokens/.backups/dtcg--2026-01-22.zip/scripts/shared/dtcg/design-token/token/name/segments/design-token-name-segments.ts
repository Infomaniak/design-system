export type DesignTokenNameSegments = readonly string[];
