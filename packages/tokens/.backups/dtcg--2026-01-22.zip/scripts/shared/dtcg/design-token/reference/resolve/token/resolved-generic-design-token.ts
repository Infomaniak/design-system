import type { ResolvedDesignToken } from './resolved-design-token.ts';

export type ResolvedGenericDesignToken = ResolvedDesignToken<any, any>;
