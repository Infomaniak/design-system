import * as z from 'zod';

export const strokeStyleDesignTokenValueLineCapSchema = z.enum(['round', 'butt', 'square']);
