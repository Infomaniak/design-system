export type StringFontFamilyDesignTokenValue = string;
