import type { AlphaNumeric } from '../../../../../../../../../../scripts/helpers/types/template-types/alpha-numeric.ts';

export type DesignTokenNameSegment = `${AlphaNumeric}${string}`;
