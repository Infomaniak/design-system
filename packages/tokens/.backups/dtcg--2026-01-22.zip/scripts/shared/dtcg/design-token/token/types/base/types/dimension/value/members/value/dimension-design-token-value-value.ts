export type DimensionDesignTokenValueValue = number | undefined;
