export type ColorDesignTokenAlpha = number | undefined;
