import type { FigmaDesignToken } from './figma-design-token.ts';

export type GenericFigmaDesignToken = FigmaDesignToken<any, any>;
