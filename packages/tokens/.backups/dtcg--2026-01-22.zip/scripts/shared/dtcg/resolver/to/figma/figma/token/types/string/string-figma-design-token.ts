import type { FigmaDesignToken } from '../../figma-design-token.ts';

export type StringFigmaDesignToken = FigmaDesignToken<'string', string>;
