import type { PredefinedStrokeStyleDesignTokenValue } from '../../../../../../../../../../design-token/token/types/composite/types/stroke-style/value/types/predefined/predefined-stroke-style-design-token-value.ts';

export function predefinedStrokeStyleDesignTokenValueToCssValue(
  value: PredefinedStrokeStyleDesignTokenValue,
): string {
  return value;
}
