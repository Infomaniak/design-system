export type CubicBezierDesignTokensCollectionTokenValue = readonly [number, number, number, number];
