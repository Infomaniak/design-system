export type StringDesignTokenName = string;
