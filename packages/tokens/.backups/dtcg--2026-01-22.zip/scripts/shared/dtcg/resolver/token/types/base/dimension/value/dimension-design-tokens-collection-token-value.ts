import type { DimensionDesignTokenValueUnit } from '../../../../../../design-token/token/types/base/types/dimension/value/members/unit/dimension-design-token-value-unit.ts';

export interface DimensionDesignTokensCollectionTokenValue {
  readonly value: number;
  readonly unit: DimensionDesignTokenValueUnit;
}
