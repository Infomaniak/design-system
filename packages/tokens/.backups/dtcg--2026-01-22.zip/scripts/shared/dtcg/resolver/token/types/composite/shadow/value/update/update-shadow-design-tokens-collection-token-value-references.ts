import type { UpdateCurlyReference } from '../../../../../../../design-token/reference/types/curly/update/update-curly-reference.ts';
import type { ShadowDesignTokensCollectionTokenValue } from '../shadow-design-tokens-collection-token-value.ts';

export function updateShadowDesignTokensCollectionTokenValueReferences(
  _value: ShadowDesignTokensCollectionTokenValue,
  _update: UpdateCurlyReference,
): ShadowDesignTokensCollectionTokenValue {
  throw 'TODO';
}
