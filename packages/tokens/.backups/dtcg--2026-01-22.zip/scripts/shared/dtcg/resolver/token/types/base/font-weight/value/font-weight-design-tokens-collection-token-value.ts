import type { FontWeightDesignTokenValue } from '../../../../../../design-token/token/types/base/types/font-weight/value/font-weight-design-token-value.ts';

export type FontWeightDesignTokensCollectionTokenValue = FontWeightDesignTokenValue;
