import Color from 'colorjs.io';

export interface FormatColorFunction {
  (color: Color): string;
}
