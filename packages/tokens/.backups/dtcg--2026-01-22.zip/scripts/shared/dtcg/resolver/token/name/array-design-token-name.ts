export type ArrayDesignTokenName = readonly string[];
