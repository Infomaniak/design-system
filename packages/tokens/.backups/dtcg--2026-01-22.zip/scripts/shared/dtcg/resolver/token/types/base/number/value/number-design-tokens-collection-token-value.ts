import type { NumberDesignTokenValue } from '../../../../../../design-token/token/types/base/types/number/value/number-design-token-value.ts';

export type NumberDesignTokensCollectionTokenValue = NumberDesignTokenValue;
