export type StringArrayFontFamilyDesignTokensCollectionTokenValue = readonly string[];
