import type { CurlyReference } from '../../../../design-token/reference/types/curly/curly-reference.ts';

export function curlyReferenceToFigmaReference(input: CurlyReference): CurlyReference {
  return input;
}
