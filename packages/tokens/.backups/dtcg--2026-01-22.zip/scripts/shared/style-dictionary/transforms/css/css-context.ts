export interface CssContext {
  readonly prefix?: string | undefined;
}
